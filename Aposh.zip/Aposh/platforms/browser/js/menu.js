<script type="text/javascript">
	$(function(){
 $('.navbar-ac').click(function(){
  $(this).next('ul').slideToggle(500);
 })
});
</script>